/* Write a program to delete duplicate elements from an array. */

#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n , arr[100] , mx = 0 ;

    cin >> n ;
    for(int i=0;i<n;i++) cin >> arr[i] ;

    sort(arr,arr+n); // You can use any sorting algorithm here

    for(int i=0;i<n;i++)
    {
        if(i!=0&&arr[i]==arr[i-1]) continue ;
        cout << arr[i] << ' ';
    }

    return 0 ;
}
